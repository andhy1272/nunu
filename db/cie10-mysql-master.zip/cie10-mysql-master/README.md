# CIE-10 MySQL

Script para crear una base de datos de CIE-10, la estructura de la tabla es la siguiente:
- Grupos.
- Subgrupos.
- Categorías.
- Diagnósticos.

Si encuentras algún error por favor repórtalo.
